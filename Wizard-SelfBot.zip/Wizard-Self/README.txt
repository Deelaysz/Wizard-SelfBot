Funções:

* Limpar mensagens privadas;
* Coletar nitro automaticamente (Nitrosniper);
* Participar de sorteios automaticamente;
* Remover amizades;
* Sair de servidores;
* Criar servidores;
* Mudar nome de Token;
* Mudar foto de Token;
* Mudar bio de Token:
* Gerador de nitro;
* Floodar report;

E MAIS! 