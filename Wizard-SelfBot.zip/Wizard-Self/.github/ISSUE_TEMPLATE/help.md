---
name: Help Needed
about: Need help fixing a problem? Let us know here!
title: Hazard Nuker [HELP]
labels: help wanted
assignees: [DeKrypted,Rdimo]

---

*Please fill out the following information:*

**Issue:**


**Operating System:**


**(OPTIONAL) Extra Info:**


**(OPTIONAL) Screenshots (Send as attatchment)**

